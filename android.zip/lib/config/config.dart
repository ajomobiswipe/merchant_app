/* ===============================================================
| Project : SIFR
| Page    : CONFIG.DART
| Date    : 21-MAR-2023
|
*  ===============================================================*/
//Export dart files
export 'app_color.dart';
export 'app_modules.dart';
export 'constants.dart';
export 'endpoints.dart';
export 'global.dart';
export 'routes.dart';
export 'static_functions.dart';
export 'validators.dart';
