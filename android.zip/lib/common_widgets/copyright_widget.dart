import 'package:flutter/cupertino.dart';

CopyRightWidget() {
  return const Column(
    children: [
      Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Copyright © 2024 OMA Emirates.',
            ),
            Text(
              'All Rights Recived.',
            ),
          ],
        ),
      ),
    ],
  );
}
